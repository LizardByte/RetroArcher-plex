=======
Credits
=======

Development Lead
----------------

* Daniel Roy Greenfeld <pydanny@gmail.com>

Contributors
------------

* Edward Betts (@EdwardBetts)
* Nick Coghlan (@ncoghlan)
* rooterkyberian (@rooterkyberian)
* OhenebaAduhene (@OhenebaAduhene)
