#!/bin/bash

python -m pytest -vv
